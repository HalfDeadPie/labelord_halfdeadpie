# This is skeleton for labelord module
# MI-PYT, task 1 (requests+click)
# File: labelord.py
from .web import *
from .cli import *

def main():
    cli(obj={})
