The Labelord application is for the replication of GitHub labels. This application uses mainly requests,
 flask and click. You are able to use list_repos, list_labels, run and run_server commands.

1. You have to create real config file 'config.cfg' in tests_unit\fixtures\configs.
2. You have to set your parameters and outputs in tests_unit/conftest_unit.py
3. Before recording cassettes you have to delete cassettes of mine

