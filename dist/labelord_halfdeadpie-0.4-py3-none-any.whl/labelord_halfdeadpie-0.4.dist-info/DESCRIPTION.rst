The Labelord application is for the replication of GitHub labels. This application uses mainly requests,
flask and click. You are able to use list_repos, list_labels, run and run_server commands.

You have to create real config file 'config.cfg' in tests_unit\fixtures\configs.

